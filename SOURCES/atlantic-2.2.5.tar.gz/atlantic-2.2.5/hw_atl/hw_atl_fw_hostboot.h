/* SPDX-License-Identifier: GPL-2.0-or-later
 * aQuantia Corporation Network Driver
 * Copyright (C) 2014-2019 aQuantia Corporation. All rights reserved
 */

/* File hw_atl_fw_hostboot.h
 */

#ifndef HW_ATL_FW_HOSTBOOT_H
#define HW_ATL_FW_HOSTBOOT_H

int hw_atl_hostboot(struct aq_hw_s *aq_hw);

#endif
