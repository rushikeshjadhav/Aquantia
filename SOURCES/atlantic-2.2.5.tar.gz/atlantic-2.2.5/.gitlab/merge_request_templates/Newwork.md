## New Work Jira Ticket

Fixes ATLDRV-XXX [Ticket title]

### Feature Description

TBD

### Solution

TBD

### Testing

TBD

### Reviewers

- [ ] Reviewed by Teamlead: @irusski
Edit and leave 1-2:
- [ ] Reviewed by: @pbelous
- [ ] Reviewed by: @ndanilov
- [ ] Reviewed by: @dbezrukov
- [ ] Reviewed by: @dbogdan
Add only for critical bugs:
- [ ] Reviewed by QA: @amoroz @alexv [Edit and leave 1]
- [ ] Reviewed by Crossteam: @kpryadko @epomozov @eastafiev @alexey [Edit and leave 1]

/label ~feature
